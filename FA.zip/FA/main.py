from fastapi import FastAPI , status
from fastapi.params import Body
from pydantic import BaseModel
import psycopg2
from psycopg2.extras import RealDictCursor 
from datetime import date, datetime, time, timedelta
from fastapi import FastAPI, HTTPException, status

 



app = FastAPI()

class Student(BaseModel): 
    name : str 
    grade : int 
    is_probation: bool = True #its default is NONE
    Major : str 
  


try:
    conn = psycopg2.connect(
        host="localhost",
        database="students ",
        user="postgres",
        password="1234",  
        port=5432, 
        cursor_factory= RealDictCursor #to get every column in the database 
    )
    cursor = conn.cursor()
    print("database connection was succefull")
except Exception as error: 
    print("Error:", error)
 


#Create -- POST -- /posts -- @app.post("/posts")

#Read -- GET -- /posts/:id --@app.get("/posts/{id}")

#Read -- GET -- /posts -- @app.get("/posts")

#Update -- PUT/PATCH -- /posts/:id -- @app.put("/posts/{id}")

#Delete -- DELETE -- /posts/:od -- @app.delete("/posts/{id}")

#----------------------------------------------------------------------



#get method 
@app.get("/") #inside the brackets there is  the path 
def root(): #function
    return {"message": "asd sad"} #result that will be returned

@app.get("/students")
def get_student():
    cursor.execute("SELECT * FROM public.students")  # Explicit schema
    students = cursor.fetchall()
    return {"data": students}

@app.post("/student", status_code=status.HTTP_201_CREATED)
def enroll_students(student: Student):
    cursor.execute("""
        INSERT INTO students (name, grade, is_probation, "Major") 
        VALUES(%s, %s, %s, %s)
    """, (
        student.name,
        student.grade,
        student.is_probation,
        student.Major,
    ))
    conn.commit() 
    return {"message": "elhamdullah"}



@app.delete("/delete/{id}", status_code=status.HTTP_200_OK)
def delete_student(id: int):
    cursor.execute("DELETE FROM students WHERE id = %s", (id,))
    conn.commit()  # Ensure changes are saved

    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Student not found")

    return {"message": "elhamullah"}